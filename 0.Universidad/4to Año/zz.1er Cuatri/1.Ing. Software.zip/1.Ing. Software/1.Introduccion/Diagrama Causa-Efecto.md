![[Pasted image 20250506181341.webp]]

# Definición 
- Representación de varios elementos (causas) de un sistema que pueden contribuir a un problema (efecto)

# Uso
- Recolección de datos 
- Estudio de procesos y situaciones 