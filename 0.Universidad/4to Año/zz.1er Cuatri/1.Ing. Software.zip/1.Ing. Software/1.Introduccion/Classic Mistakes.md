# Lista

| Más Frecuentes                                                                                                                                           | Mayor Impacto                                                                                                                             | Mayor Riesgo                                                                                                                                                |
| -------------------------------------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------- |
| - Overly optimistic schedules<br>- Unrealistic expectations<br>- Excessive multi-tasking<br>- Shortchanged quality assurance<br>- Noisy, crowded offices | - Unrealistic expectations<br>- Weak personnel<br>- Overly optimistic schedules<br>- Wishful thinking<br>- Shortchanged quality assurance | - Unrealistic expectations<br>- Overly optimistic schedules<br>- Shortchanged quality assurance<br>- Wishful thinking<br>- Confusing estimates with targets |
___
# Causas
- Falta de administración y control en proyectos
- Éxistos depende de heroes 
- Se confunde solución con requerimientos 
- Mala estimación 
- Calidad = Noción subjetiva y no se puede medir 
- Asume compromiso imposible de cumplir 
- Mantenimiento degrada el sw 
- Requerimientos poco claros 