# Definición 
- Tiene **objetivo** que guía el proyecto 
- **Temporal**, tiene principio y fin
- **Único**, no recurrente ni igual a otro
- **Recursos limitados**
- Sucesión de actividades en las que coordinar recursos 
# Dimensiones
- Funcionalidades
- Calidad
- Costo
- Tiempo
- Personas
# Proyect Managment
Definición:
- Disciplina para planificar, organizar, obtener y controlar recursos 
- Para que proyecto logre objetivos en tiempo y forma 
# Roles

| Rol                     | Definición                                                      |
| ----------------------- | --------------------------------------------------------------- |
| **Stakeholder**         | Todo involucrado en el proyecto                                 |
| **Sponsor**             | Owner del proyecto (pone dinero)<br>Toma decisiones principales |
| Usuario **Campeón**     | El que más sabe del negocio/modelo                              |
| Usuarios **Directos**   | Interactuan directamente en el sistema                          |
| Usuarios **Indirectos** | Se benefician por el sistema, pero no lo usan                   |
