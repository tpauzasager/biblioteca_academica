# Objetivos
- Comprender en que dominio estamos y determinar framework a utulizar
![[Pasted image 20250506183655.webp]]

# Contextos 
| Contexto   | Definición                                                  | Decisión                                                        | Relación causa-efecto                     | Métodología                  |
| ---------- | ----------------------------------------------------------- | --------------------------------------------------------------- | ----------------------------------------- | ---------------------------- |
| Simple     | Estable<br>Existen reglas probadas para aplicar             | **Mejor pŕactica**                                              | Clara<br>Ocurre X => Hago Y               | sensar-categorizar-responder |
| Complicado | Requiere analisis previo<br>Múltimples respuestas correctas | **Buenas prácticas**<br>(se aplica la considerada más adecuada) | Decisión del experto<br>Se evalúan hechos | sensar-analizar-responder    |
| Complejo   | Exporar soluciones <br>Se analiza y responde al problema    | **Explorar soluciones**                                         | Solo vista en retrospectiva               | probar-sensar-responder      |
| Caotico    | Se actúa para establecer orden y transofmarlo a estabilidad | **Cualquier acción** es adecuada                                | Incierta                                  | actual-sensar-responder      |
