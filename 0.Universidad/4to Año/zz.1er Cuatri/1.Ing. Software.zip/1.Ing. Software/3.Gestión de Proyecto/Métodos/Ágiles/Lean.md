# Definición 
- Enfoque en **eliminación de residuos** (que no otorgan valor añadido) para reducir tiempo y costos
- Para agilizar operaciones 
- Proposito a **largo plazo** 
- **Priorizar lo que da valor** 
# Principios

![[Pasted image 20250512155901.webp]]
![[Pasted image 20250512155916.webp]]