1. Mayor prioridad: **satisfacer al cliente**
2. Aceptar que los requisitos cambien
3. **Entregar** software funcional **frecuentemente**
4. Responsables de negocios, diseñadores y desarrolladores deben trabajar juntos día a día durante el proyecto
5. Individuos motivados
6. Conversaciones cara a cara
7. Software funcionando
8. Desarrollo sostenible
9. Atención continua a la excelencia técnica y al buen diseño
10. **Simplicidad**
11. Equipos **auto-organizados**
12. Ajuste de comportamiento para ser más efectivo