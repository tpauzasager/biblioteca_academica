Pueden ser:
	- Driver: Objetivo vital a lograr (poca o sin flexibilidad)
	- Restricción: Sin nuestro control directo (poca o sin flexibilidad) 
	- Grado de libertad: Libertad para fijar objetivos 
___
# 3 Dimensiones
![[Pasted image 20250414210426.webp|375]]
___
# 5 Dimensiones
![[Pasted image 20250414210443.webp]]

