# Definición 
- Enfoque iterativo incremental 
- Trabajo dividido en periodos de tiempo fijo (timeboxes)
Cuando usarlo?
	- Para calendarizar 
	- Cuando fecha entrega inamovible 
# Caracteristicas 
- **Tiempo** de entraga y **calidad** inamovible 
- Enfocado a cumplir con objetivo 
- Sacrificar funcionalidades 
# Precondiciones
- Lista de funcionalidades priorizadas 
- Se pueden descartar funcionalidades (para llegar a fecha de entrega)
# Condiciones
- Usuario final involucrado en proceso 
- **Equipo experto** (tamaño chico)
- Equipo define que funcionalidades se van a cumplir (y se comprometen a cumplirlas) 
# Escenario final
- Se llega con lo que se llega (pero se intenta que sea el 100%)
# vs Sprints
- Tareas no alcanzadas se pasan al siguiente sprint 
- En timebox, no se permite esto