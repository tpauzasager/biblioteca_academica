CI = Integración continua 
CD = Entrega continua 
DC = Despliegue continuo 

# CI
- Proceso de desarrollo de sw
- Donde devs ingegran código nuevo frecuentemente 
- Pruebas de compilación automáticas 

# DC
- Cambios realizados se publican automáticamente en entorno de producción 
- Hay pruebas definidas, si pasan => actualización enviada a usuarios

# CD 
- Retoma proceso de integración continua 
- Automatización de entrega de aplicaciones a los entornos de infraestructua  de usuarios 
