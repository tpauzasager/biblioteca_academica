# Identificación de configuración 
- Identificar todos los CIs 
# Control de configuración 
- Evitar cambios no autorizados
- CCB (Configuration Control Board) 
	- Grupo responsable de aprobar, evaluar cambios 
# Status Accounting 
- Permite rastrear y reportar estado de cada CI
# Auditoría de configuraicón 
- Verifica que sigan proceso y prácticas aprobadas 
- Verifica que versión final cumpla requisitos y estándares 
- 