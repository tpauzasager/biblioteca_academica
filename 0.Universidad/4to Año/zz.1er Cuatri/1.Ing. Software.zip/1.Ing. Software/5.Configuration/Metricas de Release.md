# Definición 
Metricas asociadas al flujo de building y releasing del sw 


| Métrica                  | Definición                                               |
| ------------------------ | -------------------------------------------------------- |
| Frecuencia de despliegue | Tiempo entre despliegue a producción                     |
| Change failure rate      | % de despliegues que llevaron a degradación del servicio |
| Lead time for changes    | Tiempo que tarda un commit en llegar a producción        |
| Mean time to recovery    | Tiempo para recuperarse por un incidente                 |
