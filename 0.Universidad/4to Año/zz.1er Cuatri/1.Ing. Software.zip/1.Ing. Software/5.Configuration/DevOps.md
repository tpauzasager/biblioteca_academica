# Definición 
- Fusión entre desarrollo y operaciones (producción)
- Para reducir tiempo entre cambio en sistema y pasaje a producción 
- No es metodología, es conjunto de prácticas 
## CALMS
- Cultura 
- Automatización 
- Lean -> Remover burocracia (hacer ciclo más corto)
- Métircas 
- Sharing
