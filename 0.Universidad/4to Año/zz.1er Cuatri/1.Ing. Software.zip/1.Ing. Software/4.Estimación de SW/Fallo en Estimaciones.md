1. **Optimismo**
2. Estimaciones **informales** (“estomacales”)
3. No hay historia
4. Mala definición del **alcance**
5. Novedad / **Falta de Experiencia**
6. **Complejidad** del problema a resolver
7. No se estima el tamaño
8. Porque la estimación fue buena pero cuando empieza el proyecto:
	1. **Mala administración** de los requerimientos
	2. **No hay seguimiento** y control
	3. Se confunde progreso con esfuerzo
