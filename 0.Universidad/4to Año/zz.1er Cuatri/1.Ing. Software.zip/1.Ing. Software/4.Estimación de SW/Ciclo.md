| Nombre        | Definición                                                                   |
| ------------- | ---------------------------------------------------------------------------- |
| **Estimar**   | Comenzar por estimar el tamaño                                               |
| **Medir**     | Medir como evoluciona el desarrollo del proyecto y el valor real del trabajo |
| **Registrar** | Persisitir mediciones                                                        |
| **Analizar**  | Comparar estimación con evolución real del proyecto (mediciones)             |
| **Calibrar**  | Ajustar variables/parámetros de la estimación                                |
| **Repetir**   | Volver a estimar con nuevos valores                                          |
