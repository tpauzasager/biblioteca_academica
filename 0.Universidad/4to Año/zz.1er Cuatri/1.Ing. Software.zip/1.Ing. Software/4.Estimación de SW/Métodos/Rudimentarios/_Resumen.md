# Definición 
- Basados en **experiencia e intuición**

| Nombre<br>      | Definición                                              | Ventajas              |
| --------------- | ------------------------------------------------------- | --------------------- |
| Juicio Experto  | Estimación de la exp de un **experto**                  | Rapido                |
| Pert            | Normalización del **juicio experto de varias personas** | Rapido                |
| Wideband Delphi | Estimación **estomacal** pero **consensuada**           | Rapido y colaborativo |
| Planning Poker  |                                                         |                       |
