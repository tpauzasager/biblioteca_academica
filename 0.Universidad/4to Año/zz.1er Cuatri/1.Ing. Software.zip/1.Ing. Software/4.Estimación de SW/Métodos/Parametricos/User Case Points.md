# Definición 
## Componentes
Input -> Casos de uso y transacciones (interación user-server)
Output -> Use case points | Esfuerzo = UCP * CF
# Metodología
1. **Clasificar actores**
2. **Clasificar casos de uso** (según complejidad)
3. Hallar
	1. **Peso** no ajustado de **actores** 
	2. **Peso** no ajustado de **casos de uso** 
	3. **UUCP** (use case points no ajustado)
	4. **Factor de ajuste** 
	5. **UCP** (use case points netos)