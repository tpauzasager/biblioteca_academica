# Definición 
- **Tiene inputs** (parámetros) que procesamos 


| Nombre          | Definición |
| --------------- | ---------- |
| Function Points |            |
| Use Case Points |            |
| Object Points   |            |
