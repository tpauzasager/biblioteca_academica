# Definición 
- Para **proyectos de mantenimiento** (donde ya conozco los componentes que voy a usar)
## Componenetes
**Input** -> Objetos (pantallas, reportes, módulos)
**Output** -> Object Points (ajustados)

Objeto:
	Objetos concretos de tecnologías que conozco 
	No necesariamente objetos de OOP
# Métodología 
1. Se **asigna un peso a cada objeto** en función de su complejidad 
	- Factos de ajuste == % reuso de código 
2. Se asigna **peso a cada nivel de complejidad** 
3. Se suman la cantidad de objetos de cada complejidad y sus pesos (resultado = OPs)
4. Resuo: NOP (New OP) = OP [(100* - % Reuso)/100]

