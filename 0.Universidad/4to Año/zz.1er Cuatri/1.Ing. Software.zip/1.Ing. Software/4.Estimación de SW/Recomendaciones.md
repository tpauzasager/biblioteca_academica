# Hacer 
- Juntar historia de todos los proyectos 
- Desarrollar método de estimación adecuada 
- Usar herramientas 
# No hacer 
- Descartar los métodos (por considerarlos inaplicables)
- usar métodos elaborados sin experiencia suficiente 
- Ignorar supuestos 
	- Dejar en claro nivel de incertidumbre 