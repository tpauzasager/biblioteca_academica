Oracles: 
	Principio que nos permite ver si el sw está funcionando según el criterio de alguien 
Heuristica:
	Guia provicional y falible por la que investigamos y resolvemos un problema 
# HICCUPPS

| Nombre              | Definición                                                                                                                 |
| ------------------- | -------------------------------------------------------------------------------------------------------------------------- |
| History             | Comportamiento actual de las funciones deberían ser iguales a las del pasado, suponiendo que no hay razón para que cambien |
| Image               | Comportamiento y UI/UX debería ser consistente con vision de la organización                                               |
| Comprable products  | Comparar con otros productos similares                                                                                     |
| Claims              | Producto debería compotarse como lo dicen algunas especifcaciones                                                          |
| Users' expectations |                                                                                                                            |
| Product             | Comportamiento similar para funciones similares dentro del producto                                                        |
| Purpose             | Similitud entre proposito y comportamiento de la funcionalidad                                                             |
| Statues             | Compliance y legal                                                                                                         |
