# Reflexiones 
1. Pruebas automaticas son complemento a las manuales
	No buscar automatizar todo 
	No es una meta, es una alternativa
2. Requiere tiempo 
3. Hay testings que no son automatizables (por complejidad/costo)
4. Hacer cuando estoy canchero con mi testeo manual
# Que automatizar?
![[Pasted image 20250629134423.webp]]
# Ventajas / Desventajas

| Ventajas                                                                                                           | Desventajas                                                |
| ------------------------------------------------------------------------------------------------------------------ | ---------------------------------------------------------- |
| - Cobertura<br>- Bajo costo (de ejecución)<br>- Independencia del tester<br>- Consistencia<br>- Reuso<br>- Rapidez | - Costo elevado<br>- Automatización pruede producir fallas |
