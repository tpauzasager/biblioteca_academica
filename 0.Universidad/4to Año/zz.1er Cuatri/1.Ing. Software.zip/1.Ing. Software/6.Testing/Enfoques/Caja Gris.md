# Definición 
- Combina cana negra y blanca 
- Hay conocimiento parcial (para poder generar mejores casos para caja negra)