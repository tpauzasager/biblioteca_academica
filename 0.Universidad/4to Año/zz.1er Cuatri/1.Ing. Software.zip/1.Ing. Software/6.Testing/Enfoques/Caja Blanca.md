Prueba Estructural 
# Definición 
- Basada en cómo está estructurado el componente internamente (definición)
- Para aumentar grado de cobertura de lógica interna 
## Grados de cobertura

| Grado         | Probar                           |
| ------------- | -------------------------------- |
| Sentencias    | Cada instrucción                 |
| Decisiones    | Cada salida del IF / WHILE       |
| Condiciones   | Cada expresión lógica            |
| Camino Básico | Todos los caminos independientes |
Complejidad ciclomática
- Métrica del sw para medir complejidad lógica del programa 
- $V(g) = A - N + 2$ ; A = Aristas ; N = nodos