# Definición 
 - Aprendizaje, diseño y ejecución de prueba en simultáneo 
 - Unscripted 
	 - Condiciones y casos no son diseñados 
	 - != sin preparación 
	 - Es para tener menos restricciones
 - Tester responsable en todo momento 
# Usarlo cuando 
- Conocer producto rápidamente
- Demanda feedback en poco tiempo 
- Luego del scrited testing, se requiere diversificar prueba 
- Atacar riesgo particular 
- Buscar bug particular
# Etapas
1. Reconocimiento y aprendizaje
	Identificar info importante 
2. Diseño 
	Crear draft para probar
3. Ejecución 
	Ejecutar casos y registrar resultados
4. Interpretación 
	Obtener conclusión de lo probado
# Charter
- Define misión de la sesión de testing 
	- Que, como se debe testar
	- Que tipo de defectos buscar 
- No es un plan detallado 
- 