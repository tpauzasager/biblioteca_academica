# Límite
- Decisión económica
- Pq núnca se va a poder demostrar que un sw es correcto 
# Abaratar 
- Diseñar sw para ser testeado
