
|                                             | Scripted                                            | Unscripted                                                                                     |
| ------------------------------------------- | --------------------------------------------------- | ---------------------------------------------------------------------------------------------- |
| Momento de confeción de condiciones y casos | Previa a ejecución                                  | En el momento<br>A medida que se aprende                                                       |
| Ventajas                                    | - Puede ser revisado<br>- Reusabilidad<br>- Medible | - Facíl variación de test<br>- Permite mayor cobertura de situaciones (dificiles de anticipar) |
| Desventajas                                 | - Laborioso<br>- Etapa creativa en diseño           | - Dependencia del tester (requiere creatividad y skill)                                        |
