# Costo de calidad
- Prevención 
- Medición 
# Costos de la NO calidad
Visibles:
	- Fallas internas/externas que afectan al cliente
No visibles: 
	- Duplicación de esfuerzo -> Baja motivación de equipos de trabajo 
	- Mayor costo -> Over-time constante
	- Desgaste del equipo 
	- Imagen negativa ante cliente 
# En etapas
| Analisis   | Diseño | Desarrollo | Testing | Producción |
| ---------- | ------ | ---------- | ------- | ---------- |
| Prevención | ...    | Prevención | Bajo    | Alto       |
