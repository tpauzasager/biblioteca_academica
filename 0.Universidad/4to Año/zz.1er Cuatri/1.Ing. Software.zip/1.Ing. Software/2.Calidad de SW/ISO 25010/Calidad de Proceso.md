# CMMI
Capability Maturity Model Integrated:
- Determinar madurez del proyecto 
- Organizar esfuerzo para mejorarlo 

![[Pasted image 20250407162145.webp]]
___
# ITIL
- Buenas practicas para gestion de servicios 
- Provisión y soporte de servicios IT
# SPICE
ISO
- Evaluaicón y determinación de capacidad de y mejora continua de procesos 
