# Crosby 
- Cumplir con requerimientos 
- Adecuación al suo 
- Cumplir requerimiento de alguen persona 
- ISO

# Weinberg 
- Cumplir con requerimientos de la persona
	- Calidad es valor para algunos 
	- Valor == Aquello que está dispuesto a pagar (para obtener requerimientos)
# Juran 
- Adeucación al uso 
	- Satisfacción de necesidades del PO
	- Ausencia de deficiencias 
# ISO