| Nombre              | Definición                                              | Tipo      |
| ------------------- | ------------------------------------------------------- | --------- |
| **Trascendental**   | Calidad es algo que se puede reconocer, pero no definir | Subjetiva |
| **Usuario**         | Adecuación al propósito (definido por usuario)          | Subjetiva |
| **Manufactura**     | En cuanto al proceso de producción                      | Objetiva  |
| **Producción**      | Cant de atrib de calidad que cumple                     | Objetiva  |
| **Basada en valor** | Cantidad de dinero que PO paga por producto             | Objetiva  |

