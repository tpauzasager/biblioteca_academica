# Clasificación 
Pasivos
	- No implica modificaciones de datos
	- Dificl de detectar 
Activos
	- Repetición, modificación y denegación de acceso 
	- Dificil de evitar
___
# Ataques

| Tipo           | Descripción                                              | Afecta           |
| -------------- | -------------------------------------------------------- | ---------------- |
| Interrupción   | Dejar fuera de servicio algún componente de la red       | Disponibilidad   |
| Interceptación | Persona no autorizada accede a info transmitida          | Confidencialidad |
| Modificaciṕon  | Accede a la red y modifica info y/o configuración        | Integridad       |
| Fabricación    | Falsificación de identidad para insertar info en sistema | Autenticidad     |
![[Pasted image 20250622135617.webp|592]]![[Pasted image 20250622135630.webp]]
