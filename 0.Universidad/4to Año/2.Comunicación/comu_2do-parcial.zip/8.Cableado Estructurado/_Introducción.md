# Definición 
Sistema de clableado de telecomunicaciones para edificios que busca ser generico (soportar muchos productos de telecom sin ser modificado)
## Elementos
- Puesto de trabajo 
- Cableado horizontal 
- Cableado troncal 
- Gabinete (armario de telecom)
- Sala de equimapiento de red (donde están routers, switch, servidores, ups, etc)
- Administraicón 
- Instalación de entrada
# Cableado Horizontal 
Definición
	- Cables extendidos desde puestos de trabajo hasta gabinete de telecom
	- Longitud máx -> 90mts

![[Pasted image 20250622140322.webp]]
![[Pasted image 20250622143412.webp]]
Pach cord = cable utp + conector en ambos extremos
Puesto de trabajo = Placa de pared + Pach cord + Disp. Electrónico
# Cableado Vertical 
Definición 
	- Interconexión entre gabinetes de telecom (1 por piso) y el centro de la estrella (sala de equipos/de red)
	- Se usa UTP o FO multimodo	