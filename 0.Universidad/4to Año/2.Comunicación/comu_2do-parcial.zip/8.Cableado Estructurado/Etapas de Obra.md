# Etapas
1. Planificaión y documentación 
2. Tendido de ductos y "bocas de red", instalación de racks
3. Tendido de cables 
4. Conectorizado 
5. Certificación del cableado 
## Certificación
Parametros medidos

| Parametro                  | Definición                                                                                                                                                                                                 |
| -------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Mapa de cableado <br>      | ![[Pasted image 20250622150442.webp]]                                                                                                                                                                      |
| Resistencia <br>           | Resistencia del bucle de corriente continua para                                                                                                                                                           |
| Longitud<br>               |                                                                                                                                                                                                            |
| Retardo de propagación     |                                                                                                                                                                                                            |
| Diferencia de retardo <br> | ![[Pasted image 20250622150457.webp]]<br>                                                                                                                                                                  |
| Impedancia<br>             |                                                                                                                                                                                                            |
| Atenua                     |                                                                                                                                                                                                            |
| NEXT Y FEXT                | - Near End Crosstalk<br>    - Diafonía entre pares en extreno cercano del cable<br>- Far End Crosstalk<br>    - Diafonía entre pares en extremo lejano del cable<br>	![[Pasted image 20250622150401.webp]] |
| ACR                        | Relación: Atenuación <-> Diafonía <br>Variante de S/N                                                                                                                                                      |
