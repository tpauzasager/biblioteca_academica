# Definición 
Uso
	Mantener multiples comunicaciones en simultaneo por el mismo canal 

# Tipos Multiplexación 

| Tipo | Modifica        |
| ---- | --------------- |
| FDM  | Frecuencia (f)  |
| TDM  | Tiempo (t en T) |
| CDM  | Aplica XOR (?)  |
