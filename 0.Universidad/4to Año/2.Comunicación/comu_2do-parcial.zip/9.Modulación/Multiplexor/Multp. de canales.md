![[Pasted image 20250622170902.webp]]
