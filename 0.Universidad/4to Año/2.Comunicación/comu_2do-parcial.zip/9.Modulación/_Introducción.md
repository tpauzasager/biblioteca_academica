![[Pasted image 20250622161213.webp]]

