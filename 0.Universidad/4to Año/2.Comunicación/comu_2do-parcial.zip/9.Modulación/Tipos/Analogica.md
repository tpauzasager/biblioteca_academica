# Definición
Portadora -> Analogica
Moduladora -> Analogica

| Tipo | Modulación por |
| ---- | -------------- |
| AM   | Amplitud (A)   |
| FM   | Frecuencia (f) |
