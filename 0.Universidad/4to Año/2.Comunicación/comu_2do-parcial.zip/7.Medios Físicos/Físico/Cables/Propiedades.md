E = constante dieléctrica del aislante
D = Diametro conductor externo 
d = Diametro conductor interno 

| Propiedad                     | Unidad     | Definición                                                                                            | Formula                                       |
| ----------------------------- | ---------- | ----------------------------------------------------------------------------------------------------- | --------------------------------------------- |
| **Capacidad<br>**             | [pF/m]     |                                                                                                       | $$C=\frac{24,16·E}{log(D/d)}$$                |
| **Inductancia<br>**           | [$\mu$H/m] |                                                                                                       | $$L= 0,463·log(D/d)+0,522.10⁻6$$              |
| **Impedancia caracteristica** | [Ohms]     | - Resistencia al paso de energía<br>- No depende de la frecuencia de señal (solo de caract del cable) | $$Z_0=\frac{138}{E} · log(D/d) = \sqrt{L/C}$$ |
# Efecto pelicular
- A mayor frecuencia, mayor es la atenuación 
- Porque frecuencias altas viajas por extremo 

# Impedancia vs Impedancia caracteristica

| Impedancia                                            | Impedancia Característica                                                       |
| ----------------------------------------------------- | ------------------------------------------------------------------------------- |
| Resistencia que se opone al paso de corriente alterna | Impedancia para cable con longitud infinita                                     |
| Depende de frecuencia                                 | No depende de frecuencia <br>Depende de caracteristicas constructivas del cable |
