# Telefónico
![[Pasted image 20250622102145.webp]]
# Multipar aéreo
![[Pasted image 20250622102425.webp]]
# Coaxial
![[Pasted image 20250622102446.webp]]
