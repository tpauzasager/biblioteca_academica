# Definición 
Conjunto de dispositivos que permiten conversión de señal eléctrica <-> óptica
Para transmitir datos a través demedios ópticos (FO)
