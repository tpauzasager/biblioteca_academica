# Refracción 
![[Pasted image 20250622104705.webp]]

## Cono de aceptación
![[Pasted image 20250622105553.webp]]
### Ángulo de refracción máximo 
$$\theta_2 = \pi/2 => sin(\theta_2)=1$$$$1 > sin(\theta_1) = \frac{n_2}{n_1} > 0$$$$=> n_1 > n_2$$
### Ángulo de apertura 
##### $$\phi = arcsen(\sqrt{n_1²-n_2²}$$
##### $$NA =\text{número de apertura}= sin(\phi)$$
