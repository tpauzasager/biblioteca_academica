
| Tipo                        | Caracteristica                                                                                                                                                 | Usos            |
| --------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------- |
| Multimodo<br>**Escalonado** | - Refracción por áncluos pronunciados<br>- Modos viajan a diferentes velocidades<br>- Mayor dispersión modal => Distancia limitada                             | Redes cortas    |
| Multimodo<br>**Gradual**    | - Indice de reflacción con variación gradual (perfil parabólico)<br>- Rayos se curvan suavemente<br>- Menor dispersión modal<br>- Mayor eficiencia y velocidad | LAN             |
| **Monomodo**                | - Nucleo delgado<br>- Solo un modo de luz <br>- No hay dispersión modal <br>- Baja atenuación y muy alta capacidad                                             | Larga distancia |
![[Pasted image 20250622104514.webp]]
![[Pasted image 20250622104557.webp]]
