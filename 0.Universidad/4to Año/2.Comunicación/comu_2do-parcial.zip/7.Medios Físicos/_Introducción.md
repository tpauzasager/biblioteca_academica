# Tipos

| Tipo        | Ejemplo          |
| ----------- | ---------------- |
| Alambrico   | Cables           |
| Inalambrico | Antena, Satélite |
## Señales
- Electricas
- Electromagneticas
- Opticas 