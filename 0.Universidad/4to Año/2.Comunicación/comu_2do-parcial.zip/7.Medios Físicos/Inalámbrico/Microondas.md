# Definición 
- Sistema que trabaja en frecuencias ultraelevadas (UHF)
- Usan haz radioeléctrico (como un rayo de luz) para establecer enlace punta a punto (entre estaciones transreceptoras)
