# Tipos

| Tipo            | Definición                                                                              | Altura       |
| --------------- | --------------------------------------------------------------------------------------- | ------------ |
| Geoestacionario | Velocidad angular igual a la rotación de la tierra (está fijo con respecto a la tierra) | 35700km      |
| Orbita baja     | Movimiento rápido respecto al suelo                                                     | [160;2000]km |
