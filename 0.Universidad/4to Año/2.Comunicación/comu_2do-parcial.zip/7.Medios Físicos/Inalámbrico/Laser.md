# Tipos

| Tipo          | Caracteristica |
| ------------- | -------------- |
| Gaseos        |                |
| Líquido       |                |
| Sólido        |                |
| Semiconductor |                |
