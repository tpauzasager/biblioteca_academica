# Tamaño de antena
#### $$\lambda = \frac{c}{f}$$
Puede ser:
	Onda completa -> $\lambda$
	Media onda       -> $\lambda/2$
	Cuarto de onda -> $\lambda/4$
# Perdida en espacio abierto
#### $$L=32,4+20·log(d~[km])+20·log(f~[MHz])$$
d = Distancia entre antenas 
# Distancia máx entre antenas
#### $$VH = DH_1+DH_2$$ $$DH ~= 4,14·\sqrt{H}$$
H = Altura de antena
