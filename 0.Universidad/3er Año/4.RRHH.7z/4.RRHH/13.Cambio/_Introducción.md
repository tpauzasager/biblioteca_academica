# Factores en Gestión del Cambio
| Factor         | Definición             |
| -------------- | ---------------------- |
| Visión         | Meta                   |
| Motivación     |                        |
| Habilidades    | Capacidades necesarias |
| Recursos       |                        |
| Plan de acción |                        |
![[Pasted image 20241107093450.png]]

