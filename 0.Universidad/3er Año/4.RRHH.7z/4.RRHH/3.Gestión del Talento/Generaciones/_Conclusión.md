Con las caracteristicas de cada generación, una organización queda enrriquecida 
Orgs que valoran diferencias -> Generan mejores politicas de RH
