Definición:
	Proceso de desarrollar, incorporar y retener recursos humanos a la fuerza laboral
	Destacar personas con alto potencial 