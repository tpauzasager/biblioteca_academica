Era del Capital Humano:
	Organizaciones ponene al empleado por sobre todo 
	Empleado se siente parte de la compañía, asumiento responsabilidades por fracasos y éxitos 

1ro Empleados
2do Clientes
3ro Ganacias
___
# Dietas
![[Pasted image 20240929203747.png]]

| Criterio           | Descripción                                                  |
| ------------------ | ------------------------------------------------------------ |
| Productividad      | No gastar más de lo que se tiene                             |
| Relaciones Humanas | Empleados felices (cuidar capital humano)                    |
| Calidad            | Clientes felices (que vuelvan los clientes no los productos) |
Criterios aplican a los 3 niveles de una compañía (Genrecial, Equipo, Individual)
___
# Aquarium Administrativo
Definición:
	Cuando gerencia ve cibras buenas => No hay nada que cambiar
	Cuando caen un poco => Se espera que mejoren, se espera que mejoren
	Cuando son graves => Ya es moy tarde 

Hay que cambiar antes de que sea necesario, para poder elegir nuestras estrategias