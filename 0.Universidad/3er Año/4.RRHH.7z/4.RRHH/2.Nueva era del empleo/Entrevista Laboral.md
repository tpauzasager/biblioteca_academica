| Tip           | Descripción                                                |
| ------------- | ---------------------------------------------------------- |
| Puntualidad   | Llegar con el tiempo adecuado (ni mucho antes, ni después) |
| Persentación  | Adaptar aspecto a la política de la empresa                |
| Preparación   | Preparar respuestas previsibles                            |
| Documentación | Llevar documentación solicitada y de utilidad (CV)         |
| Investigación | Sobre la empresa                                           |
| Honestidad    | Ser uno mismo, no crear personajes                         |
| Actitud       | No mostrr apatía, si no entusiasmo y disponibilidad        |
| Entrevistador | Deja la iniciativa al entrevistador, no interumpir         |
| Preguntar     | Siempre que se necesite aclarar o ampliar información      |
| Estilo        | No hablar mal de jefes, empleos, compañeros anteriores     |
| Dialogo       | No discutir con entrevistador                              |
| Fracasos      | Capacidad para comunicar fracasos y aprendizajes           |
| Muletillas    | Evitar muletillas                                          |
| Autocontrol   | No mostrar nervios o inseguridad                           |
| Registrar     | Preguntas o datos de interés                               |
| Despedida     | Cortés, formal                                             |

| Preguntas Frecuentes                   | Descripción                                               |
| -------------------------------------- | --------------------------------------------------------- |
| Que remuneración espera obtener?       |                                                           |
| Por qué dejaste tu último trabajo?     | Quiere saber que estás buscando en tu próximo puesto.<br> |
| Por qué toma tanto tiempo para llamar? |                                                           |


