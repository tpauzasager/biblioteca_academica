Definición:
	Empresas que utilizan la web para comunicarse y dirigir
	Fortalece idea de equipo 
___
# Cultura 2.0 
Definición:
	No es cambio técnologico, si no, **cambio de mentalidad**
	Pasar de la gestión del **control** a la gestión de las **pesonas**

| Nombre             | Descripción                                   |
| ------------------ | --------------------------------------------- |
| Confianza          |                                               |
| Colaboración       | Para compartir conocimiento y co-crear        |
| Corresponsabilidad | Personas comprometidas dan valor a la empresa |
| Humildad           | Para dejasnos enseñar y aceptar ideas ajenas  |
___
# Empleo 2.0
Definición:
	No es buscar oportunidades, es **hacer que te encuentren**
	Técnicas d eposicionamiento
	Reputación profesional

Web 2.0
	sitios que facilitan compartir información, interoperabilidad y diseño centrado en usuario
	Nos da herramientas para ser emprendedores y buscar personas para diseñar nuestra vida profesional 

# Consejos para encontrar empleo
1. Informarse: 
	Buscar recursos en internet acerca de opotunidades de trabajo e información acerca del mismo
2. Hacer que te busquen: 
	**Crear contenido y compartirlo**, para generar mejor posicionamiento y captar interés 
	Crear buena **reputación** **profesional**
3. Uso de redes sociales
___
# Networking
Definición: 
	Contactos son el 2do método de reclutamiento más utlizado por empresas (1ro es portal de empleo)
___
# Portales de empleo en Internet
Si persona no encuentra empleo en métodos convencionales => Poco probable que lo haga en redes sociales (es necesario cumplir requisitos y exigencias)
2.0 da muchas oportunidades, pero solo para personas proactivas y con iniciativa 
