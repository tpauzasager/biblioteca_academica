Definición:
	Avanzar al ritmo de la sociedad y las empresas 
	Capacidad de aprender nuevas habilidades a lo largo de la vida
	Responder con repidez a cambios 

Dimensiones
1. Capacidad de continuar aprendiendo 
2. Deseo de conocer por el gusto de conocer y actitud positiva hacia nuevos retos 

Evaluación

| Nombre        | Descripción                                                                                   |
| ------------- | --------------------------------------------------------------------------------------------- |
| Explorador    | Busca vivir nuevas aventuras<br>Persona curiosa que disfruta adquiriendo nuevos conocimeintos |
| Motivado      | Tiene actitud, desea crecer, aprender<br>Proactivo ante nuevos retos                          |
| Inconformista |                                                                                               |
