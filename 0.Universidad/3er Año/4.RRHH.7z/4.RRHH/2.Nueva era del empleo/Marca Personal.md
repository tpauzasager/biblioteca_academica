Tiende a la promoción personal a través de la percepción que los demás tiene de uno 
Incluye la apariencia externa, impresión que causa y manera en que la persona se diferencia de los demás 

Objetivos: 
	- Causar una impresión duradera y sugiera el beneficio de la contratación 
	- Ser visto como diferentes y capaz de aportar valor único e irrepetible 
	- Salir de anonimato (CV)

Elaborar plan personal de marketing 
	- Pensarnos como empresa donde todos los roles somos nosotros 
	- Preguntas: 
		- Quien soy?
		- Que quiero hacer?
		- Fortalezar y áreas de mejora? 
		- Donde quiero trabajar? 
		- Cuando estoy disponible? 
	- Parte On-line: LinkedIn , Twitter
	- Parte Off-line: CV

Consejos:
	- Pensarnos como una marca
	- Monitorear presencia en redes 
	- Tener página web propia
	- Encontrar formas de producir valor
	- Dar propósito a lo que compartis
	- Asociarse con otras marcas fuertes 
	- Reinventate
