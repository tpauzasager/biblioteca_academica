Definición:
	Cambio en mentalidad de compañías
	Una nueva cultura de las organizaciones 
	Poner al cliente y empleado en 1er lugar de la estrategia de negocio 

Mentalidad digital
	Lo que la gente espera y necesita VS Diseños de las orgs sobre expectativas y necesidades
	Nuevos candidatos eligen donde trabajar y ponene condiciones propias

Competencias 2.0:
	Construyo y Transformo / Decido con datos / Agilidad y Aprendizaje 