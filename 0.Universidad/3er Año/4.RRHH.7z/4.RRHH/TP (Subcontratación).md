# Tipos
# Casos de Estudio
## 1. Apple
Apple ha mantenido una larga relación de outsourcing con compañías como Foxconn y Pegatron, principalmente para la fabricación de sus dispositivos, como iPhones y iPads. Aunque esta estrategia ha sido utilizada durante décadas, sigue siendo clave en los últimos años, especialmente con el incremento de la demanda global y la necesidad de diversificación de la producción, como en India y Vietnam.

## 2. Nike
La mayoría de la producción de calzado y ropa de Nike se realiza mediante outsourcing en países como Vietnam, China e Indonesia. Nike ha continuado este enfoque para aprovechar la mano de obra barata, con acuerdos de manufactura con proveedores de larga data, optimizando la cadena de suministro global.

## 3. Nestlé
Nestlé ha optado por outsourcing en áreas como la gestión de recursos humanos, tecnología de la información y logística. Subcontratan ciertos servicios relacionados con la cadena de suministro y la distribución global para mejorar la eficiencia operativa y reducir costos, así como la subcontratación de servicios de TI para la gestión de sistemas.
___
## New York (comida rápida)
En 2015 se propuso (para 2021) subir progresivamente los salarios de los trabajadores de comida rápida, de $8.74 /h -->  $15 /h.
Estas empresas basan su sistema de costos entorno a sus salarios bajos, para mantener sus precios bajos 
Como medidas se tomaron:
1. In-Shore:
	- Limpieza, mantenimiento, soporte administrativo 
2. Off-Shore: 
	- Call centers, soporte técnico, gestión de pedidos online, atención al cliente 
	- India, Filipinas
	- Near-Shore: México, Colombia, Costa Rica 
3. Automatización (kioscos autoservicio -> sin personal de mostrador) y reducción de personal

