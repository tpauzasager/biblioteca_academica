- Orgs pueden cultivar cultura empresarial más consiente y ética
- Debe ir más allá de minimizar costos 
___
# Fundamentos 
Fredy Kofman

| Fundamento                                 | Descripción                                               |
| ------------------------------------------ | --------------------------------------------------------- |
| Propósito más allá del beneficio económico | Crear valor económico, social y ético<br>Fijarse en todos |
| Impacto en todas las partes interesadas    | Considerar como acciones de empresa afectan a todos       |
| Liderazgo auténtico y consciente           |                                                           |
___
# Acciones
| Acción                                                   | Descripción                            |
| -------------------------------------------------------- | -------------------------------------- |
| Definir propósito claro y significativo                  | Que impacto quiero generar en el mundo |
| Integrar consideraciones de todas las partes interesadas |                                        |
| Promover liderazgo auténtico y consciente                |                                        |
| Fomentar cultura organizacional ética                    |                                        |
| Medir impacto                                            |                                        |
| Capacitación y desarrollo                                |                                        |
| Colaboraciones y asociaciones                            |                                        |
|                                                          |                                        |
	- Más allá del dinero
- Integrar consideraciones de todas las partes interesadas de la org
- Promover liderazgo auténtico y consciente 
	- Estilo de liderazgo que coincida con propósito de empresa 
- Fomentar cultura organizacional ética 
	- Comunicar y asegurar cumplimiento 
- Medir impacto 
- Capacitación y desarrollo 
	- Para que empleados puedan comprender y contribuir al propósito de empresa
- Colaboración y asociaciones 
	- Buscar colaborar con otra empresa 

# Como fomentar como Líder
1. Comunicación abierta y honesta
	- Para que empleados se sientan libres de expresar ideas
2. Modelar comportamiento deseables 
	- Lideres son modelos a seguir
3. Estables metas y expectativas claras
4. ...

*Integrar todos estos conceptos es comprender como podemos trabajar en empresas con foco en las personas, con un liderazgo autentico y con valores sin perder rentabilidad del negocio*

