- Busca crear valor a largo plazo, promover impacto positivo en sociedad (no solo generar dinero)

