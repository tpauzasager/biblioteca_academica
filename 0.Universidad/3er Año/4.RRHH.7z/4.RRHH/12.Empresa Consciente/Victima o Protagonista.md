| Victima                                                                                                                                                                                                                                             | Protagonista                                                                      |
| --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------- |
| Percibe su vida como influenciada por fuerzas externas<br>Desafios == Obstaculos insuperables<br>Resignación y falta de responsabilidad personal Asume responabilidad de su vida y acciones<br>Busca activamente el control sobre circunstancias  s | Asume responsabilidad<br>Busca proactivamente el control sobre sus circunstancias |

# Proceso de conversión 
Cambiar la forma en la que se percibe y responde a circunstancias de la vida 
1. Conciencia personal
2. Asumir responsabilidad
3. Cambiar enfoque
	- Enfocarse en lo se puede cambiar 
4. Cambio mentalidad
	- Como uno se ve a sí mismo y a los demás  
5. Desarrollar habilidad de afrontamiento 
6. Practicar gratitud 
