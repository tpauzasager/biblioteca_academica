Definición: 
	Como una compañía integra el conjunto de valores en sus propias políticas prácticas y en toma de decisiones

Abordaje:
	Razonamiento consecuencialista: 
		Ética es hacer cosas que promuevan la felidad 
	Razonamiento no consecuencialista:
		Basado en acciones no en consecuencias
		Conducta sigue norma independientemente de resultados

# Impacto
| Nivel | Descripción                             |
| ----- | --------------------------------------- |
| 1     | Más graves                              |
| 2     | Afecta gran cant de personas            |
| 3     | No suele ser peligroso para vida humana |
___
# Tipos razonamiento
| Tipo                 | Descripción                                 |
| -------------------- | ------------------------------------------- |
| Consecuencialista    | Ética es hacer cosas para prmover felicidad |
| No Consecuencialista | Llevar a cabo principios establecidos       |
___
# Razonamientos
Consecuencialista:
	Resultado antes que accionar 
No consecuencialista:
	Acciones antes que resultado
	