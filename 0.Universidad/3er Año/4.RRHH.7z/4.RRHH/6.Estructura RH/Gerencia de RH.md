Otros nombres: 
	Capital Humano - Dto. de personal - RH - Desarrollo humano - Talento humano - Dirección de personas 
___
# Foco en las Personas
___
# Areas 
Nomica - Administración - Compensaciones
 - empleos - Capacitación - RSE - Relaciones laborales - HR busines partener

| Nombre                                   | Acciones                                                                                                                                                                                                                              |
| ---------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Nomina                                   | Liquidación de sueldos/ganancias<br>Adelanto de sueldo<br>Liquidaciones Finales<br>Certificaciones de servicios<br>Vacaciones<br>Licencias especiales<br>Embargos                                                                     |
| Administración                           | Elaboración de legajos<br>Ingresos<br>Trámites de Obra social y prepaga<br>Mantenimiento de organigrama<br>Sistemas para organización                                                                                                 |
| Compensaciones                           | Descripciones de puestos<br>Bandas salariales<br>Promociones y análisis remueratiovo<br>Beneficios para empleados                                                                                                                     |
| Empleos                                  | Recutamiento y selección de personal<br>Búsqueda interna y de mercado<br>Entrevistas<br>Programas <br>Pasantías                                                                                                                       |
| Capacitación                             | Cursos técnicos y normativos<br>Inducción<br>Campus e learning<br>Programas de desarrollo de carrera<br>Evaluación de Desempeño                                                                                                       |
| RSE (Responsabilidad social empresarial) | Actividades de voluntariados social<br>Programas de apoyo a emprendedores<br>Diversidad<br>Programas sustentables<br>Memorias de la empresa<br>Actividades para familia<br>Tareas con fundaciones                                     |
| HR Business Partner                      | Nexo entre negocios y RRHH<br>Alinear objetivos de la empresa con los de RRHH<br>Gestionar desarrollo de perfiles con alto potencial<br>Capacidad de negociación y resolución de conflicto<br>Liderar procesos de cambio e innovación |
