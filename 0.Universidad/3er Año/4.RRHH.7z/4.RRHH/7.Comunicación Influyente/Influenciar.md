Influir:
	- Capacidad de hacer o decir algo que genere proceso de transformación en interlocutor
	- Mediante comunicación 
	- Proceso voluntario

Manipular:
	Afecta volunda o libre elección de personas (mentir, ocultar info)

Donde se Aplica:
	- Eq de trabajos
	- Presentaciones
	- Familia
	- Presentaciones
___
# Efecto Pigmalión
(Profecía autocuplida)
Persona consigue lo que se propinía por la creencia de que puede conseguirlo 
- Altas espectativas en otra persona aumentan su rendimiento 
