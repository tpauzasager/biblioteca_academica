
| Técnia/Herramienta                                        | Descripción                                                                                  |
| --------------------------------------------------------- | -------------------------------------------------------------------------------------------- |
| **Etiqueta**                                              | Decir que una persona es capaz y esta intentará adaptarse para cumplir esa etiqueta          |
| **Sensación de oportunidad única**                        | Factor tiempo y stock                                                                        |
| Lograr muchos Sí                                          |                                                                                              |
| Tendencia a masividad                                     | Tendencia a hacer lo que hacen los demás                                                     |
| **Reducir cant opciones**                                 |                                                                                              |
| Ganar o no perder?                                        | Personas prefieren no perder antes que ganar                                                 |
| **Regalar utoría o razón a cambio de conseguir objetivo** | Hacer que sientan que la idea es suya                                                        |
| Deseo de sentirse importante                              |                                                                                              |
| Comunicar advertencias                                    | Advertencia solo útil cuando receptor tiene herramientas para combatirla                     |
| Justificar argumentando peticiones aunque sean obvias     |                                                                                              |
| 1er paso                                                  | Pedir algo sencillo y luego lo que verdaderamente se quiere                                  |
| Pensamiento positivo                                      |                                                                                              |
| Reconocer realidad de los demás                           | Más fácil influir en gente de aquello en lo que ya cree. El desafío es reconocer su realidad |
| Conseguir apoyos independientes                           | Pocos quieren ser los 1ros o ultimos en estar de acuerdo con otra idea                       |
| Decir "podemos esto"                                      | Evitar la palabra NO (genera rechazo)                                                        |

Influir en comunicar
Comunicar es generar acción 
Acción genera cambio 