| Organización | Estrategía                                   | Estructura                                                                      | Cultura                                        | Sitemas                            |
| ------------ | -------------------------------------------- | ------------------------------------------------------------------------------- | ---------------------------------------------- | ---------------------------------- |
| Emprendedora | Agresiva<br>Corto plazo<br>Intuitiva         | Simple (alta genrecia, personal operatvio)<br>Informal                          | Poder<br>Lealtad<br>Gran familia               | Mal necesario                      |
| Prescriptiva | Liderazgo por costos bajos<br>Largo plazo    | Niveles jerárquicos<br>División de responsabilidades por especialidad<br>Formal | Roles<br>Premia eficiencia y evitar conflictos | Control por análisis de desvíos    |
| Que aprende  | Desarrollo continuo<br>Corto y mediano plazo | Unides y equipos combinados                                                     | Creativa<br>Orientada a solución de problemas  | De apoyo<br>Lidear con lo complejo |
___
# Emprendedora
Definición:
	Empresa joven, pequeña o mediana
	Fundadas por pionero con una idea que podía hacerse productiva 
___
# Prescriptiva
Definición:
	Burocracias 
	Funcionan como maquinas (hombres y recursos son materiales)
	Grandes y antiguas 
	Procesos estandarizados (bajos costos)
___
# Que aprende 
Definición:
	Organización que aprende a aprender 
	Pueden ser y mantenerse competentes 
	Desarrollarse == Aprender sin perder identidad
Aprendizaje multilateral:
	En todos los niveles de aprendizaje (conducta, reglas, insights, principios)
Aprender a aprender 
	Aprendizaje orientado al metaprendizaje
	En orgs diferentes, la crisis termina cuando se evade el problema
	En
___
# Organización que Desaprende
Definición:
	Organización burocacia que experimenta un cambio
Anteproyecto:
	proceso de reorganización que intenta cambiar la conducta
Proceso de aprendizaje: 
	Cambio organizacional debe ser aprendido por todos los individuos
	Proceso de desaprendizaje (olvidarse de lo viejo para aprender lo nuevo)