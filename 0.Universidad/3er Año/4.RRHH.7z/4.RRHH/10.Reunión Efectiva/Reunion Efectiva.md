Efectiva cuando:
	- Se **logran metas propuestas**
	- Participantes **trabajan juntos** constructiva y positivamente 
	- Participantes dispuestos a **compartir ides** y conceptos
	- Se cierra con certeza de haber avanzado
	- Se hace en el **menor tiempo posible**  
___
# Características
1. Planificación
	- Definir proposito -> Duración -> Integrantes 
	- Proposito -> Concreto y claro
1. Fromalidad o Informalidad
2. Elementos
	- Minutas
	- Partiacipación: Cada uno tiene rol activo
	- Comunicación: Hablar y escuchar
	- Moderador: 
___
Pautas básicas:
- Evaluar si realment ese necesita una reunión presencial
- Identificar quien debe asistir
- Identificar y comunicar objetivo a lograr
- Seeguir agenda durante la reunión 
- Enviar minuta estableciendo pasos a seguir 