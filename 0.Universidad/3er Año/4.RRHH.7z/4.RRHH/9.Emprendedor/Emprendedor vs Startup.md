Emprendedores -> Quienes descubren nuevo negocio
Startup -> Negocio tradicional, no se prioriza ganacia monetaria