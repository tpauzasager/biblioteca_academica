# Definición
Desarrollo de proyectos innovadores para obtener beneficio
___
# Pasos para el éxito
1. Descubrir la oportunidad
2. Evaluar la oportunidad
3. Comprometer recursos
4. Entrada al mercado 
5. Despegue
6. Madurezy expansión 
7. Cosechando lo sembrado 