Entrepreneur:
	Hacia afuera de la organización 
Intrepreneur:
	Empreder dentro de la empresa 

# Definición
- Persona que precibe una oportunidad de negocio 
- Capaz de tener nuevas ideas
- No cambio de personalidad -> Trabajar más duro
___
# Innovación
Modificación radical de producto
Producto no necesita ser nuevo, pero implica cambio discernible 
___________
# Tipos de Emprendedor
- Descubridor de negocios
	- Ver lo que nadie vio
- Creador de negocios
	- 
- Gestor de negocios
	- Generan la maduración del negocio
# Estilos 
- Persuasivo: Tiene carisma para influir de manera positiva 
- Por azar: Heredó 
- Especialista: Avocado a nicho específico muy ténico
- Rastreados: Persive necesidades sin explotar en el mercado
- Visionario: Vision hacia futuro
___
# Puntos Importantes
1. El equipo es lo más importante
2. Leer el contexto y definir competencias 
3. Hipótesis + Piloto/MVP + Validar + Recolectar datos + aprender
4. Escala, sostenibilidad y crecimiento controlado 
5. Roadmap
6. Levantar fondos (Bootstrapping o inversión)
7. Formalizar el camino
8. Toda empresa es una empresa de comunicación 

