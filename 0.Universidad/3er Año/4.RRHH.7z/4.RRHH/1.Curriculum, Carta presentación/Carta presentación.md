Objetivo:
	Llamar la atención del selector, marcar la diferencia con los demás postulantes 
	Expresar interes por la empresa y el puesto 
	Misma importancia que CV

Consideraciones: 
	- Profesional y de forma clara, concisa 
	- Contenido -> Explica porque es apto para el puesto
	- Contiene remuneración pretendida y/o horarios disponibles (si lo piden)

Distribución
 
| Sección     | Descripción                                                                             |
| ----------- | --------------------------------------------------------------------------------------- |
| Datos       | Margen derecho: Fecha de elaboración<br>Margen izquierdo: Datos personales y empresa    |
| Saludo      | Dirigir a la persona que publicó el aviso (Estimado/s, Sr/es, Ingeniero/a, Lienciado/a) |
| 1er Párrafo | Indicar datos de la publicación del puesto                                              |
| 2do Párrafo | Indica istuación actual (puesto laboral y carrera)                                      |
| 3er Párrafo | Finalizar con cumplido estándar<br>Firma y aclaración (sobre margen derecho)            |
