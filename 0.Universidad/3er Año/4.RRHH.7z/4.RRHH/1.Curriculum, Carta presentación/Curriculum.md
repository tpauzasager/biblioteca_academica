# Recomendaciones
- Claro, legible y estructurado
- Tener en cuenta la empresa a la que es dirigido 
- No inventar y poner lo más relevante 
- Ser creativo (atraer la atención)
- Se pueden mencionar hobbies (más que nada deportes de trabajo en equipo)
- Agregar objetivo profesional (metas de tu desarrollo para dentro de 5 años)
- Largo máximo de 2 carillas 
- Emepzar con la experiencia/educación más reciente 
Evitar
- Agregar certificados de estudio/notas, cartas de recomendación, referencias 
- Agregar titulo "Curriculum Vitae"
- Usar pronombres (yo, nosotros, ellos)
- Información privada
- Remuneración pretendida, disponibilidad horaria
- Fecha de nacimiento, pero no edad 
# Secciones
| Nombre                                | Recomendación                                                                                            |
| ------------------------------------- | -------------------------------------------------------------------------------------------------------- |
| Datos Personales                      | Contenido mínimo:<br>- Nombre completo / DNI / dirección / email / teléfono                              |
| Eduacación y Formación                | Colegios y año de cursada<br>Estudios en transcurso: Indicar año de inicio y posible año de finalización |
| Experiencia Laboral                   | Empresa en donde trabajasta, puesto, tareas principales y duración                                       |
| Conocimientos de Idiomas              |                                                                                                          |
| Conocimientos técnicos e Informáticos | Destacar herramientas que conoces y su nivel                                                             |
# Parrafos

| Número | Contenido                                                                                          |
| ------ | -------------------------------------------------------------------------------------------------- |
| 1      | No poner nombre<br>Pusto al que me postulo<br>Medio de referencia (de donde me entere del trabajo) |
| 2      | Que estoy estudiando y experiencia laboral                                                         |
| 3      | Saludos, firma y aclaración                                                                        |
___
# VideoCurriculum

| Ventaja                         | Descripción                                                                    |
| ------------------------------- | ------------------------------------------------------------------------------ |
| 1ra selección                   | Durante preparación, candidato aprende habilidades útiles para la comunicación |
| Mejora habilidades de condidato | Aporta info que solo se vería en una entrevista                                |
| Menos engaños                   |                                                                                |
| Facilidad de búsqueda           |                                                                                |

Sectores en donde aplica: 
	Enfocado al Internet, Idiomas, Atención al público y ventas

Consejos
- Buena iluminación y sonorización 
- Ser natural y reflejar cualidades de forma positiva 
- Duración de 1 minuto  
- Aspecto físico: La mejor sonriza (1ra impresión importa)
- Dicción: El candidato se dirige al destinatario de forma directa
- Postura: 
- Contenido: Evitar muletillas y excesiva familiaridad. Mismo contenido y estructura que en curriculum papel, evitar dar fechas
- Cierre: Terminar con datos de contacto 
- Formato: No debe pesar mucho

Partes:
	1. Presentación: habla de formación 
	2. Narración de experiencia previa
	3. Cierre (refleja valores y pretenciones profesionales)
___ 
# Por realidad aumentada
