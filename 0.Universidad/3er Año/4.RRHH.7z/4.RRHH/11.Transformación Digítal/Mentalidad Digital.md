Definición:
	- Evolución de las **culturas organizacionales**

# Evolución de Organizaciones
| Color   |                  | Definición                                                                       |
| ------- | ---------------- | -------------------------------------------------------------------------------- |
| Rojo    | Manada lobos     | Lealtad por recompensas y castigos<br>División del trabajo<br>Autoridad al mando |
| Ambar   | Ejército         | Jerarquía formal<br>Procesos                                                     |
| Naranja | Máquina          | Innovación <br>Responsabilidad<br>Meritocracia                                   |
| Verde   | Familia          | Empoderamiento<br>Cultura y valores<br>Grupos de interés                         |
| Teal    | Sistema complejo | Proposito evolutivo<br>Autogestión <br>Plenitud                                  |
# Organización Roja
![[Pasted image 20241107084341.png]]

# Organización Ambar
![[Pasted image 20241107084421.png]]

# Organización Naranja
![[Pasted image 20241107084520.png]]

# Organización Verde
![[Pasted image 20241107084554.png]]
- Muy comprometída con RSE
# Organización Teal
![[Pasted image 20241107084707.png]]
- Plenitud: Lo que buscán los trabajadores (diferente para cada generación)

