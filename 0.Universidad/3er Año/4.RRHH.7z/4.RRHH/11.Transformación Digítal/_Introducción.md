Definición:
	- **NO** es digitalización 
	- Cambio en mentalidad de compañías 
	- **Cambio Cultural y Estratégico** que afecta a todas las **organizaciones** y sus Stakeholders (lo que abarcan)
	- Poner al **cliente y empleado en 1er lugar** de la estrategia del negocio

# Competencias
- Construyo y transformo 
- Decido con datos
- Agilidad y aprendizaje
- Diseño expreciecias
- Creo con otro 
	- Creativo a partir de la colaboración 

# Propuesta de valor
![[Pasted image 20241107085314.png]]
- Relevante:
	- Que el prod resuelva necesidad del cliente
- Diferente:
	- Por que el cliente debería elegirme a mi?
- Creíble:
	- Coherencia entre lo que dice que hace y lo que hace 

