# Sustentabilidad
- Satisfacer necesidaes de la generación presente sin comprometer la capacidad de las generaciones futuras de satisfacer sus necesidades 
## Dimensiones
- Social: Equidad de las soluciones propuestas (finalidad del desarrollo siempre es ética y social)
- Económica: Eficiencia económica
- Ecológica: Prudencia ecológica
- Cultural: Soluciones deben ser culturalmente aceptables 
- Espacial (territorial): Equilibrios espaciales considerando la planificación socio-económica y uso de recursos conjuntamente
## Desarrollo sustentable
- Avanzar en 3 ámbitos (económico, ambiental y social)