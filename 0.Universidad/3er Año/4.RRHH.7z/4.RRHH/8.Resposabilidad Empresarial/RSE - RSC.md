Definición:
	Contribución activa y voluntaria al mejoramiento social, económico y ambiental por parte de las empresas 

Resposabilidades éticas
	- Servir la sociedad con productos útiles
	- Respetar derechos humanos
	- Respetar medio ambiente 
	- Cumplir las leyes 

Diferencias entre RSE, RSC y RS:
	RSC (corporativa) -> Grandes empresa 
	RSE (empresarial) -> Todas las empresas
	RS (responsabilidad social) -> Todos los ciudadanos

Medición de RSE:
	- No existe estándar aceptado para medición
	- Se suelen usar informes elaborados por propias entidades 

